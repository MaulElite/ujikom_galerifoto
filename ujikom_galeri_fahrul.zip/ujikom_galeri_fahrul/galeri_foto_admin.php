<?php
// Dapatkan ID pengguna yang sedang aktif
$id_user = $_SESSION['user']['id_user'];
$isAdmin = $_SESSION['user']['roles'] == 'admin'; // Sesuaikan jika session untuk role atau status admin berbeda

// Ambil ID foto dari parameter GET
$id = $_GET['id'];

// Query untuk mengambil data foto yang sesuai dengan ID
$query = mysqli_query($koneksi, "SELECT * FROM foto WHERE id_foto = $id");
$data = mysqli_fetch_array($query);

// Cek apakah foto sudah di-like oleh pengguna
$checkLikeQuery = mysqli_query($koneksi, "SELECT * FROM likefoto WHERE id_foto='{$data['id_foto']}' AND id_user='$id_user'");
$isLiked = mysqli_num_rows($checkLikeQuery) > 0;

// Query untuk menghitung jumlah like dan komentar
$likeCountQuery = mysqli_query($koneksi, "SELECT COUNT(*) AS total_likes FROM likefoto WHERE id_foto='{$data['id_foto']}'");
$likeCount = mysqli_fetch_assoc($likeCountQuery)['total_likes'] ?? 0;
$commentCountQuery = mysqli_query($koneksi, "SELECT COUNT(*) AS total_comments FROM komentar WHERE id_foto='{$data['id_foto']}'");
$commentCount = mysqli_fetch_assoc($commentCountQuery)['total_comments'] ?? 0;
?>

<div class="container-fluid" style="background-image: url('gambar/sky.png'); background-size: cover; background-position: center; min-height: 100vh;">
    <br>
    <form method="post" enctype="multipart/form-data">
        <div class="d-flex1 justify-content-center align-items-start bg-overlay">
            <div class="col-md-6">
                <a href="gambar/<?php echo $data['gambar']; ?>" target="_blank">
                    <img src="gambar/<?php echo $data['gambar']; ?>" width="600" height="700" alt="gambar">
                </a>

                <div>
                    <a href="?page=galeri_like&id=<?php echo $data['id_foto']; ?>" class="btn btn-link">
                        <i class="bi bi-heart-fill" style="font-size: 24px; color: <?php echo $isLiked ? 'red' : 'black'; ?>;"></i> 
                        <span><?php echo $likeCount; ?></span>
                    </a>
                    <a href="?page=galeri_komentar&id=<?php echo $data['id_foto']; ?>" class="btn btn-link">
                        <i class="bi bi-chat-left-text" style="font-size: 24px;"></i> 
                        <span><?php echo $commentCount; ?></span>
                    </a>
                    
                    <?php if ($data['id_user'] == $id_user || $isAdmin): // Tampilkan jika pengguna yang upload atau admin ?>
                        <a href="?page=galeri_ubah&id=<?php echo $data['id_foto']; ?>" class="btn btn-warning text-white">
                            <i class="bi bi-pencil-square"></i>
                        </a>
                        <a href="?page=galeri_hapus_admin&id=<?php echo $data['id_foto']; ?>" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus foto ini?')">
                            <i class="bi bi-trash"></i>
                        </a>
                    <?php endif; ?>
                    
                    <br><br>
                    <a href="?page=galeri_admin" class="btn bg-gradient-danger text-white">Kembali</a>
                </div>
            </div>
            <div class="col-md-6">
                <h1><?php echo ($data['judul']); ?></h1>
                <br>
                <p class="text-gray"><?php echo ($data['deskripsi']); ?></p>
            </div>
        </div>
    </form>
    <br>

    <style>
        .d-flex1 {
            display: flex;
            gap: 20px;
            align-items: start;
        }
        .col-md-6 img {
            width: 100%;
            max-width: 600px;
            height: auto;
        }
        .bg-overlay {
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            width: 80%;
        }
        .col-md-6 p {
            word-wrap: break-word;
        }
    </style>
</div>
