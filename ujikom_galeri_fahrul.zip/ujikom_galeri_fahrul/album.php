<?php
// Cek apakah pengguna adalah admin
$isAdmin = $_SESSION['user']['roles'] == 'admin'; // Pastikan role admin sesuai dengan session yang kamu gunakan
$id_user = $_SESSION['user']['id_user']; // Ambil id_user dari sesi pengguna yang sedang login

// Query untuk menampilkan album. Jika admin, tampilkan semua album. Jika bukan admin, tampilkan hanya album milik pengguna.
if ($isAdmin) {
    $query = mysqli_query($koneksi, "SELECT * FROM album");
} else {
    $query = mysqli_query($koneksi, "SELECT * FROM album WHERE id_user = '$id_user'");
}

$no = 1;
?>

<div class="container-fluid" style="background-image: url('gambar/sky.png'); background-size: cover; background-position: center; min-height: 100vh;">
    <h1 class="h3 mb-4 text-white">Daftar Album</h1>
    <a href="?page=galeri_album" class="btn btn-info">+ Tambah Album</a>
    <a href="?page=galeri_tambah" class="btn btn-warning">+ Tambah Galeri</a>
    <br>
    <div class="table-responsive">
        <br>
        <table class="table table-bordered text-white bg-gradient-primary" id="dataTable" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th><b>No</b></th>
                    <th><b>Nama Album</b></th>
                    <th>Deskripsi</th>
                    <th>Tanggal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($data = mysqli_fetch_array($query)) {
                ?>
                <tr>
                    <td><?php echo $no++ ?></td>
                    <td>
                         <?php echo $data['nama_album']; ?>
                            <a href="?page=galeri&id_album=<?php echo $data['id_album']; ?>" class="btn bg-gradient-success text-white">Cek</a>
                    </td>
                    <td><?php echo $data['deskripsi']; ?></td>
                    <td><?php echo $data['tanggal']; ?></td>
                    <td>
                            <a href="?page=edit_album&id=<?php echo $data['id_album']; ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="?page=hapus_album&id=<?php echo $data['id_album']; ?>" class="btn btn-danger btn-sm" >Hapus</a>
                    </td>
                </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
