<?php
    $id = $_GET['id'];

    $hapuslikee = mysqli_query($koneksi, "DELETE FROM likefoto WHERE id_foto='$id'");
    $hapuskomenn = mysqli_query($koneksi, "DELETE FROM komentar WHERE id_foto='$id'");
    $query = mysqli_query($koneksi, "DELETE FROM foto WHERE id_foto=$id");
    if($query > 0) {
        echo '<script> alert("Hapus Data Berhasil"); location.href="?page=album"</script>';
    }else{
        echo '<script> alert("Hapus Data Gagal") </script>';
    }
?>