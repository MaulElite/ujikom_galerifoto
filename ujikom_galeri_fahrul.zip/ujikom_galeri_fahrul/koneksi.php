<?php
// Periksa status sesi
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Koneksi database
$koneksi = mysqli_connect("localhost", "root", "", "ujikom_fahrul");
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
