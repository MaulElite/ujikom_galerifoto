<div class="container-fluid" style="background-image: url('gambar/sky.png'); background-size: cover; background-position: center; min-height: 100vh;">
    <br>    
    <div class="row">

        <?php
            // Cek apakah ada parameter id_album di URL
            $id_album = isset($_GET['id_album']) ? $_GET['id_album'] : '';

            // Query untuk mengambil semua foto, atau hanya dari album tertentu jika id_album ada
            $query = mysqli_query($koneksi, "
                SELECT foto.*, album.nama_album 
                FROM foto 
                LEFT JOIN album ON album.id_album = foto.id_album " .
                ($id_album ? "WHERE foto.id_album = '$id_album'" : "")
            );

            while ($data = mysqli_fetch_array($query)) {
                // Query untuk menghitung jumlah like untuk foto ini
                $likeCountQuery = mysqli_query($koneksi, "SELECT COUNT(*) AS total_likes FROM likefoto WHERE id_foto='{$data['id_foto']}'");
                $likeCount = mysqli_fetch_assoc($likeCountQuery)['total_likes'] ?? 0;

                // Query untuk menghitung jumlah komentar untuk foto ini
                $commentCountQuery = mysqli_query($koneksi, "SELECT COUNT(*) AS total_comments FROM komentar WHERE id_foto='{$data['id_foto']}'");
                $commentCount = mysqli_fetch_assoc($commentCountQuery)['total_comments'] ?? 0;
                
                ?>
                <div class="col-md-2 mb-3">
                    <div class="card">
                        <a href="gambar/<?php echo $data['gambar']; ?>" target="_blank">
                            <img src="gambar/<?php echo $data['gambar']; ?>" class="card-img-top img-fluid" alt="<?php echo $data['judul']; ?>" style="object-fit: cover; height: 200px;">
                        </a>
                        <a href="?page=galeri_foto_admin&id=<?php echo $data['id_foto'] ?>"  class="btn btn-primary">
                        <div class="card-body bg-gradient-primary">
                            
                            <h6 class="text-white">>></h6>
                        </div>
                        </a>
                    </div>
                </div>
                <?php
            }
        ?>
    </div>
</div>
