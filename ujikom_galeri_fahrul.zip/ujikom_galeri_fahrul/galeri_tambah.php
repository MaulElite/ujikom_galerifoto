<?php
if(isset($_POST['judul'])){
    $judul = $_POST['judul'];
    $deskripsi = $_POST['deskripsi'];
    $id_album = $_POST['id_album'];
    $tanggal = $_POST['tanggal'];
    $id_user = $_SESSION['user']['id_user'];

    $gambar = $_FILES['gambar'];
    $nama_gambar = $gambar['name'];

    if (isset($_FILES['gambar'])) {
        $gambar = $_FILES['gambar'];
        
        // Cek apakah ada kesalahan upload
        if ($gambar['error'] !== UPLOAD_ERR_OK) {
            die("Upload file error: " . $gambar['error']);
        }

        // Periksa tipe MIME file untuk memastikan itu adalah gambar
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/jpg', 'image/webp'];
        $fileType = mime_content_type($gambar['tmp_name']);
        
        if (!in_array($fileType, $allowedTypes)) {
            die("Hanya file gambar yang diperbolehkan untuk diupload.");
        }
        
        // Pastikan folder tujuan ada dan dapat ditulisi
        $targetDir = 'gambar/';
        if (!is_dir($targetDir) || !is_writable($targetDir)) {
            die("Folder tujuan tidak ada atau tidak dapat ditulisi.");
        }
        
        // Pindahkan file
        if (move_uploaded_file($gambar['tmp_name'], $targetDir . $gambar['name'])) {
            echo "File berhasil diupload.";
        } else {
            echo "File gagal diupload.";
        }
    }
    
    $query = mysqli_query($koneksi, "INSERT INTO foto (judul,deskripsi,id_album,tanggal,gambar,id_user) VALUES('$judul','$deskripsi','$id_album','$tanggal','$nama_gambar','$id_user')");

    if($query > 0) {
        echo '<script> alert("Tambah Data Berhasil"); location.href = "?page=album";</script>';
    }else{
        echo '<script> alert("Tambah Data Gagal") </script>';
    }
}
?>


<div class="container-fluid" style="background-image: url('gambar/animesky.jpg'); background-size: cover; background-position: center; min-height: 100vh;">

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-white">Galeri Foto</h1>
    <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
            class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
</div>
            <br><br>
            <form method="post" enctype="multipart/form-data">
                <table class="table bg-gradient-primary text-white">
                    <tr>
                        <td width="150">Judul</td>
                        <td width="1">:</td>
                        <td><input type="text" name="judul" class="form-control"></td>
                    </tr>
                    <tr>
                        <td>Deskripsi</td>
                        <td>:</td>
                        <td><input type="text" name="deskripsi" class="form-control"></td>
                    </tr>
                    <tr>
                        <td>Album</td>
                        <td>:</td>
                        <td>
                            <select name="id_album" class="form-select form-control">
                                <?php
                                    $id_user = $_SESSION['user']['id_user']; // Ambil ID user yang sedang login
                                    $al = mysqli_query($koneksi, "SELECT * FROM album WHERE id_user = '$id_user'");                                    
                                    while($album = mysqli_fetch_array($al)){
                                        ?>
                                        <option value="<?php echo $album['id_album']?>"><?php echo $album['nama_album']?></option>
                                        <?php
                                    }
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Tanggal</td>
                        <td>:</td>
                        <td><input type="date" name="tanggal" class="form-control"></td>
                    </tr>
                    <tr>
                        <td>Gambar</td>
                        <td>:</td>
                        <td><input type="file" name="gambar" class="form-control"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                            <a href="?page=album" class="btn btn-danger">Kembali</a>
                        </td>
                    </tr>
                </table>

            </form>

</div>