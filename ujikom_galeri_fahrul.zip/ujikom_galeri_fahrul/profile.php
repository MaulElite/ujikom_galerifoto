<?php
include "koneksi.php";
if (!isset($_SESSION['user'])) {
    header("location:login.php");
}

$user = $_SESSION['user'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Profile - Galeri Foto Online</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body>
    <div class="container-fluid" style="background-image: url('gambar/sky.png'); background-size: cover; background-position: center; min-height: 100vh;">
<br><br>
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Informasi Pengguna</h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Nama Lengkap:</strong> <?php echo $user['nama_lengkap']; ?></p>
                        <p><strong>Email:</strong> <?php echo $user['email']; ?></p>
                        <br>
                        <a href="index.php" class="btn btn-danger">Kembali</a>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Username:</strong> <?php echo $user['username']; ?></p>
                        <p><strong>Role:</strong> <?php echo $user['roles']; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
</body>

</html>
