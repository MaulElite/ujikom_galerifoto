<?php
include "koneksi.php"; // Pastikan koneksi sudah di-include

$id = $_GET['id'];

// Hapus semua likes yang mengaitkan ke foto
$hapuslike = mysqli_query($koneksi, "DELETE FROM likefoto WHERE id_foto='$id'");
$hapuskomen = mysqli_query($koneksi, "DELETE FROM komentar WHERE id_foto='$id'");

// Hapus foto setelah menghapus likes
$hapusfoto = mysqli_query($koneksi, "DELETE FROM foto WHERE id_foto='$id'");

if ($hapusfoto) {
    echo '<script>alert("Hapus Data Berhasil"); location.href="?page=galeri_admin";</script>';
} else {
    echo '<script>alert("Hapus Data Gagal: ' . mysqli_error($koneksi) . '"); location.href="?page=galeri_admin";</script>';
}
?>
