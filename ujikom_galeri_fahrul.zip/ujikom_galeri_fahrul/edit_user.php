<?php
include "koneksi.php";

$id = intval($_GET['id']);

if (isset($_POST['nama_lengkap'])) {
    $nama_lengkap = $_POST['nama_lengkap'];

    $query = mysqli_query($koneksi, "UPDATE user SET nama_lengkap='$nama_lengkap' WHERE id_user=$id");

    if ($query) {
        echo '<script> alert("Ubah User Berhasil"); location.href="?page=user" </script>';
    } else {
        echo '<script> alert("Ubah User Gagal: ' . mysqli_error($koneksi) . '"); </script>';
    }
    
}

$query = mysqli_query($koneksi, "SELECT * FROM album WHERE id_album=$id");
$data = mysqli_fetch_array($query);
?>

<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Galeri Foto</h1>
        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
            <i class="fas fa-download fa-sm text-white-50"></i> Generate Report
        </a>
    </div>
    <a href="?page=user" class="btn btn-danger">Kembali</a>
    <br><br>
    <form method="post" enctype="multipart/form-data">
        <table class="table">
            <tr>
                <td width="150">Nama Lengkap</td>
                <td width="1">:</td>
                <td><input type="text" name="nama_lengkap" value="<?php echo $data['nama_lengkap']; ?>" class="form-control"></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                    <button type="reset" class="btn btn-danger">Reset</button>
                </td>
            </tr>
        </table>
    </form>
</div>
