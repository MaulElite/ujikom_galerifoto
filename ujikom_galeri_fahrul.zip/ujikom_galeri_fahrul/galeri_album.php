<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_album = $_POST['nama_album'];
    $deskripsi = $_POST['deskripsi'];
    $tanggal = $_POST['tanggal'];
    
    // Ambil id_user dari session
    $id_user = $_SESSION['user']['id_user']; // Pastikan 'id' ada di session

    // Query untuk menyimpan data album
    $query = "INSERT INTO album (nama_album, deskripsi, tanggal, id_user) VALUES ('$nama_album', '$deskripsi', '$tanggal', '$id_user')";
    
    if (mysqli_query($koneksi, $query)) {
        echo '<script>
                alert("Album Telah Di Tambahkan"); location.href = "?page=album";</script>';
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($koneksi);
    }
}
?>

<div class="container-fluid" style="background-image: url('gambar/animesky.jpg'); background-size: cover; background-position: center; min-height: 100vh;">
    <h2 class="text-white">Form Tambah Album</h2>
    <form method="POST" class="bg-gradient-primary text-white">
        <div class="mb-3">
            <br>
            <label for="nama_album" class="form-label">Nama Album:</label>
            <input type="text" id="nama_album" name="nama_album" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="deskripsi" class="form-label">Deskripsi:</label>
            <textarea id="deskripsi" name="deskripsi" class="form-control" required></textarea>
        </div>
        <div class="mb-3">
            <label for="tanggal" class="form-label">Tanggal Rilis:</label>
            <input type="date" id="tanggal" name="tanggal" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Tambah Album</button>
        <a href="?page=album" class="btn btn-danger">Kembali</a>
    </form>
</div>
