<?php
    $id = $_GET['id'];

    // Mulai transaksi
    mysqli_begin_transaction($koneksi);

    try {
        // Hapus semua like yang terkait dengan foto di album ini
        $hapusLike = mysqli_query($koneksi, "DELETE likefoto FROM likefoto 
                                             INNER JOIN foto ON likefoto.id_foto = foto.id_foto 
                                             WHERE foto.id_album = '$id'");

        // Hapus semua komentar yang terkait dengan foto di album ini
        $hapusKomen = mysqli_query($koneksi, "DELETE komentar FROM komentar 
                                              INNER JOIN foto ON komentar.id_foto = foto.id_foto 
                                              WHERE foto.id_album = '$id'");

        // Hapus semua foto di dalam album
        $hapusFoto = mysqli_query($koneksi, "DELETE FROM foto WHERE id_album = '$id'");

        // Hapus album
        $hapusAlbum = mysqli_query($koneksi, "DELETE FROM album WHERE id_album = '$id'");

        // Cek apakah semua query berhasil
        if ($hapusLike && $hapusKomen && $hapusFoto && $hapusAlbum) {
            mysqli_commit($koneksi);
            echo '<script> alert("Hapus Album Berhasil"); location.href="?page=album"</script>';
        } else {
            // Jika ada query yang gagal, lakukan rollback
            mysqli_rollback($koneksi);
            echo '<script> alert("Hapus Album Gagal") </script>';
        }
    } catch (Exception $e) {
        // Jika ada error, lakukan rollback
        mysqli_rollback($koneksi);
        echo '<script> alert("Hapus Album Gagal") </script>';
    }
?>
