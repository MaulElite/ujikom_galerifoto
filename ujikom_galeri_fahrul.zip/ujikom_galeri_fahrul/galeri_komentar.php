<?php
$id = $_GET['id'];

// Query dan simpan data foto
$query = mysqli_query($koneksi, "SELECT * FROM foto WHERE id_foto = $id");
$fotoData = mysqli_fetch_array($query); // Gunakan $fotoData alih-alih $data

// Menyimpan ID foto dalam variabel terpisah
$id_foto = $fotoData['id_foto'];
?>

<div class="container-fluid">
    <h1 class="h3 mb-0 text-gray-800">Komentar</h1>

    <form method="post" enctype="multipart/form-data">
        <table class="table">
            <tr>
                <td>
                    <a href="gambar/<?php echo $fotoData['gambar']; ?>" target="_blank">
                        <img src="gambar/<?php echo $fotoData['gambar']; ?>" width="600" height="700" alt="gambar">
                    </a>
                </td>
            </tr>
        </table>
    </form>

    <h1 class="h3 mb-0 text-gray-800">Komentar Foto</h1>

    <?php
    if (isset($_POST['komentar'])) {
        $komentar = $_POST['komentar'];
        $tanggal = date("Y/m/d");
        $id_user = $_SESSION['user']['id_user'];

        $query = mysqli_query($koneksi, "INSERT INTO komentar (id_foto, id_user, komentar, tanggal) VALUES ('$id', '$id_user', '$komentar', '$tanggal')");

        if ($query > 0) {
            echo '<script>alert("Komentar Telah Ditambahkan")</script>';
        } else {
            echo '<script>alert("Komentar Gagal Ditambahkan")</script>';
        }
    }

    // Loop untuk menampilkan komentar
    $queryKomentar = mysqli_query($koneksi, "SELECT * FROM komentar LEFT JOIN user ON user.id_user = komentar.id_user WHERE komentar.id_foto = $id");
    while ($komentarData = mysqli_fetch_array($queryKomentar)) {
        $user_id_comment = $komentarData['id_user'];
        ?>
        <div class="card mb-2">
            <div class="card-header bg-gradient-primary text-white">
                <?php echo $komentarData['nama_lengkap'] . ' (' . $komentarData['tanggal'] . ')'; ?>
                <?php if ($user_id_comment == $_SESSION['user']['id_user'] || $_SESSION['user']['roles'] == 'admin') { ?>
                    <a href="?page=hapus_komentar&id=<?php echo $komentarData['id_komentar']; ?>" class="btn btn-danger btn-sm float-right" onclick="return confirm('Apakah Anda yakin ingin menghapus Komentar ini?')">Hapus</a>
                    <a href="?page=edit_komentar&id=<?php echo $komentarData['id_komentar']; ?>" class="btn btn-warning btn-sm float-right mr-2">Edit</a>
                <?php } ?>
            </div>
            <div class="card-body"><?php echo $komentarData['komentar']; ?></div>
        </div>
        <?php
    }
    ?>

    <form method="post">
        <label>Masukan Komentar</label>
        <textarea name="komentar" rows="5" class="form-control"></textarea>
        <br>
        <button type="submit" class="btn bg-gradient-primary text-white">Simpan</button>
        <a href="?page=galeri_foto&id=<?php echo $id_foto; ?>" class="btn bg-gradient-danger text-white">Kembali</a>
    </form>
</div>
<br>