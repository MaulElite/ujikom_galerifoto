<div class="container-fluid"  style="background-image: url('gambar/animesky.jpg'); background-size: cover; background-position: center; min-height: 100vh;" >
    <h1 class="h3 mb-4 text-white ">Daftar Pengguna</h1>
    <div class="table-responsive">
        <table class="table table-bordered text-white bg-gradient-primary" id="dataTable" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th><b>ID</b></th>
                    <th><b>Nama Lengkap</b>
                    </th>
                    <th>Email</th>
                    <th>Alamat</th>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $query = mysqli_query($koneksi, "SELECT * FROM user");
                    while ($data = mysqli_fetch_array($query)) {
                ?>
                <tr>
                    <td><?php echo $data['id_user']; ?></td>
                    <td><?php echo $data['nama_lengkap']; ?></td>
                    <td><?php echo $data['email']; ?></td>
                    <td><?php echo $data['alamat']; ?></td>
                    <td><?php echo $data['username']; ?></td>
                    <td><?php echo $data['roles']; ?></td>
                    <td>
                        <a href="?page=edit_user&id=<?php echo $data['id_user']; ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="?page=hapus_user&id=<?php echo $data['id_user']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus User ini?')">Hapus</a>
                    </td>
                </tr>
                <?php
                    }
                ?>
            </tbody>
        </table>
    </div>
</div>
