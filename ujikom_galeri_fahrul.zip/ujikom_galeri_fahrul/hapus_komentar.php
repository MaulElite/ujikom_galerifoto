<?php
include "koneksi.php";

$id_komentar = $_GET['id'];
$id_user = $_SESSION['user']['id_user'];

// Cek koneksi database
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Cek apakah komentar tersebut milik user yang sedang login
$query = mysqli_query($koneksi, "SELECT id_user FROM komentar WHERE id_komentar = $id_komentar");
$komentarData = mysqli_fetch_array($query);

if ($komentarData['id_user'] == $id_user || $_SESSION['user']['roles'] == 'admin') {
    $deleteQuery = mysqli_query($koneksi, "DELETE FROM komentar WHERE id_komentar = $id_komentar");
    if ($deleteQuery) {
        echo '<script>alert("Komentar berhasil dihapus."); location.href="?page=galeri";</script>';
    } else {
        echo '<script>alert("Gagal menghapus komentar."); location.href="?page=galeri";</script>';
    }
} else {
    echo '<script>alert("Anda tidak memiliki izin untuk menghapus komentar ini."); location.href="?page=galeri";</script>';
}
?>
