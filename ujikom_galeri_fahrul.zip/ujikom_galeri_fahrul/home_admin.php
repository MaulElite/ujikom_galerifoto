<div class="container-fluid" style="background-image: url('gambar/images.jpeg'); background-size: cover; background-position: center; min-height: 100vh;">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4" style="background-color: rgba(255, 255, 255, 0.8); padding: 10px; border-radius: 5px;">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
        <div class="container">
    <div class="row">
        <div class="col-md-6">
            <a href="?page=galeri_tambah" class="btn btn-primary">+ Tambah Galeri</a>
        </div>
        <div class="col-md-6">
            <a href="?page=galeri_album" class="btn btn-primary">+ Tambah Album</a>
        </div>
    </div>
</div>
        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
                
    </div>

    
</div>
