<?php
    $id = $_GET['id'];

    $query = mysqli_query($koneksi, "DELETE FROM user WHERE id_user=$id");
    if($query > 0) {
        echo '<script> alert("Hapus User Berhasil"); location.href="?page=user"</script>';
    }else{
        echo '<script> alert("Hapus Data Gagal") </script>';
    }
?>