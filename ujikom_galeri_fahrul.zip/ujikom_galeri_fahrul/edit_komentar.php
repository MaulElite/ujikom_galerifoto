<?php
include "koneksi.php";

$id_komentar = $_GET['id'];
$id_user = $_SESSION['user']['id_user'];

$query = mysqli_query($koneksi, "SELECT * FROM komentar WHERE id_komentar = $id_komentar");
$data = mysqli_fetch_array($query);

// Cek apakah komentar tersebut milik user yang sedang login
if ($data['id_user'] != $id_user && $_SESSION['user']['roles'] != 'admin') {
    echo '<script>alert("Anda tidak memiliki izin untuk mengedit komentar ini."); location.href="?page=galeri";</script>';
    exit;
}

if (isset($_POST['komentar'])) {
    $komentar = $_POST['komentar'];
    $updateQuery = mysqli_query($koneksi, "UPDATE komentar SET komentar = '$komentar' WHERE id_komentar = $id_komentar");
    if ($updateQuery) {
        echo '<script>alert("Komentar berhasil diubah.")</script>';
    } else {
        echo '<script>alert("Gagal mengubah komentar.");</script>';
    }
}
?>

<div class="container-fluid">
    <h1 class="h3 mb-0 text-gray-800">Edit Komentar</h1>

    <form method="post">
        <label>Masukan Komentar</label>
        <textarea name="komentar" rows="5" class="form-control"><?php echo $data['komentar']; ?></textarea>
        <br>
        <button type="submit" class="btn btn-primary">Simpan</button>
        <a href="?page=galeri" class="btn btn-danger">Kembali</a>
    </form>
</div>
